/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Seed admin user
    const users = app.findCollectionByNameOrId("users");
    try {
      app.findAuthRecordByEmail("users", "admin@easygamernews.com");
    } catch (_) {
      const admin = new Record(users);
      admin.setEmail("admin@easygamernews.com");
      admin.setPassword("EasyAdmin2026!");
      admin.set("name", "Admin");
      app.save(admin);
    }

    // Seed articles
    const articles = app.findCollectionByNameOrId("articles");

    const seed = [
      {
        slug: "shader-compilation-finally-solved-on-pc",
        platforms: ["pc"],
        title: "Shader compilation stutter is finally getting a real fix on PC",
        dek: "Two major engines now ship precompiled pipeline caches at install time. We tested six games to see whether the frame-time graphs agree.",
        author: "Marta Kaine",
        date: "2026-07-29",
        readTime: "7 min",
        image: "https://images.hostinger.com/f3860b77-5885-4b82-ada5-7c12c98ae67f.png",
        tags: ["Performance", "Benchmarks"],
        body: [
          "For the better part of a decade, the single most reliable way to ruin a PC launch was to ship a game that compiles its shaders while you play. The result was the same every time: a beautiful world, and a hitch every time you turned a corner.",
          "The new approach is unglamorous but effective. Pipeline state objects are gathered from studio playtests, bundled with the build, and warmed during installation instead of during gameplay. Install times go up by two to four minutes; the 1% low frame rate goes up by a great deal more.",
          "Across our six-game test set, 1% lows improved between 18% and 41% on a mid-range machine, with the biggest gains on six-core CPUs where background compilation had the least headroom to hide.",
          "It is not a universal fix. Driver updates still invalidate caches, and open-world streaming introduces its own hitching that has nothing to do with shaders. But the worst-case stutter, the kind that made benchmarks unreadable, is measurably on its way out.",
        ],
      },
      {
        slug: "xbox-handheld-strategy",
        platforms: ["xbox"],
        title: "Xbox is quietly rebuilding itself around the handheld",
        dek: "A full-screen console shell, aggressive power profiles, and a library that follows you. The strategy is clearer than the marketing.",
        author: "Dev Ramanathan",
        date: "2026-07-27",
        readTime: "6 min",
        image: "https://images.hostinger.com/5933b74b-2a71-4e16-b956-0e4779d6c133.png",
        tags: ["Hardware", "Analysis"],
        body: [
          "The most interesting thing about the current Xbox roadmap is not a console at all. It is a shell: a full-screen, controller-first interface that boots straight into your library and suspends the rest of the operating system in the background.",
          "On a handheld, that shell buys back roughly 1.5GB of memory and a meaningful slice of idle CPU time. In practice it is the difference between a 30fps target holding and a 30fps target wobbling.",
          "What this signals is a platform that has stopped defining itself by a box under the television. The account is the platform. The hardware is a delivery mechanism, and increasingly there is more than one of them.",
        ],
      },
      {
        slug: "playstation-single-player-bet",
        platforms: ["playstation"],
        title: "PlayStation doubles down on the long single-player game",
        dek: "Three first-party studios have shifted off live-service projects. The slate that replaces them looks a lot like 2018.",
        author: "Iris Bellamy",
        date: "2026-07-26",
        readTime: "5 min",
        image: "https://images.hostinger.com/4a660ce3-01ad-42ad-9003-e01ff55a23bd.png",
        tags: ["Industry", "First-party"],
        body: [
          "After a four-year detour into persistent worlds and seasonal roadmaps, the first-party slate is turning back toward the thing it was always best at: a 25-hour story with a credits roll.",
          "Internally the argument was never creative, it was financial. Live-service games have a wider outcome distribution: the upside is enormous and the downside is a cancelled project with four years of payroll attached.",
          "The near-term result is a thinner 2027 and a dense 2028. The longer-term result may be a platform identity that is legible again to the people buying the hardware.",
        ],
      },
      {
        slug: "esports-league-reset",
        platforms: ["pc"],
        title: "The franchised esports league is over. What replaces it is messier",
        dek: "Open circuits, regional qualifiers, and tournament organizers with actual leverage again.",
        author: "Marta Kaine",
        date: "2026-07-24",
        readTime: "8 min",
        image: "https://images.hostinger.com/379741bd-0b81-4ac6-ac98-e48ac57d0a8e.png",
        tags: ["Esports"],
        body: [
          "Franchising promised stability: guaranteed slots, guaranteed revenue share, guaranteed calendars. It delivered stability to publishers and a slow squeeze to everyone else.",
          "The open circuits that replaced it are chaotic by design. Regional qualifiers feed international events, rosters churn mid-season, and the barrier to a new organization is a good roster rather than a large cheque.",
          "Viewership is down in aggregate and up per event. That trade is the whole story of the current era.",
        ],
      },
      {
        slug: "couch-co-op-comeback",
        platforms: ["playstation"],
        title: "Local co-op is having a genuine comeback, and the numbers back it",
        dek: "Split-screen shipped in more retail releases this year than in the previous three combined.",
        author: "Iris Bellamy",
        date: "2026-07-22",
        readTime: "4 min",
        image: "https://images.hostinger.com/6ba4921a-168f-45cc-9b29-d74424c4f032.png",
        tags: ["Features"],
        body: [
          "Split-screen was killed by resolution targets. Rendering two viewports at 4K was untenable, so studios quietly dropped the mode and blamed engine complexity.",
          "Dynamic resolution and upscaling changed the maths. A second viewport now costs far less than it used to, and publishers have noticed that co-op games sell two copies to the same household surprisingly often.",
          "The result is the healthiest year for couch multiplayer since the last console generation, and the only games trend of 2026 that is unambiguously good news.",
        ],
      },
      {
        slug: "game-pass-price-restructure",
        platforms: ["xbox"],
        title: "What the subscription price restructure actually changes for players",
        dek: "Three tiers became two, day-one releases moved, and the cloud tier got quietly better.",
        author: "Dev Ramanathan",
        date: "2026-07-20",
        readTime: "5 min",
        image: "https://images.hostinger.com/6ba4921a-168f-45cc-9b29-d74424c4f032.png",
        tags: ["Subscriptions"],
        body: [
          "The headline is a price rise. The detail underneath is a reshuffle of which games land on which tier on day one, and that detail matters more to most subscribers than the monthly figure.",
          "Cloud streaming, long treated as a bonus, now runs on newer hardware with a lower input-latency floor. On a wired connection it is genuinely playable for anything that is not a competitive shooter.",
          "If you play three or four big releases a year, the maths still favours the subscription. If you play one, it stopped favouring it some time ago.",
        ],
      },
      {
        slug: "anti-cheat-kernel-debate",
        platforms: ["pc"],
        title: "The kernel anti-cheat debate is not about cheating anymore",
        dek: "Players lost the privacy argument years ago. The new fight is about who gets to boot your machine.",
        author: "Marta Kaine",
        date: "2026-07-18",
        readTime: "9 min",
        image: "https://images.hostinger.com/f3860b77-5885-4b82-ada5-7c12c98ae67f.png",
        tags: ["Security", "Analysis"],
        body: [
          "Kernel-level anti-cheat works. That is the uncomfortable premise every critique has to start from: ring-zero drivers catch a class of cheat that user-space detection simply cannot see.",
          "The cost is a driver with total system access, shipped by a game studio, updated on a game studio release cadence. One bad update is a fleet-wide outage, and we have now had several.",
          "Attestation-based approaches move the trust anchor into hardware and out of the game. They are slower to adopt, harder to spoof, and the only credible path out of the current arrangement.",
        ],
      },
      {
        slug: "living-room-setup-guide",
        platforms: ["playstation"],
        title: "The 2026 living-room setup guide: HDR, VRR, and what to ignore",
        dek: "A short list of settings that matter and a much longer list of marketing terms that do not.",
        author: "Iris Bellamy",
        date: "2026-07-15",
        readTime: "6 min",
        image: "https://images.hostinger.com/6ba4921a-168f-45cc-9b29-d74424c4f032.png",
        tags: ["Guides", "Hardware"],
        body: [
          "Turn on game mode. Turn off every motion-smoothing feature your television has invented a proprietary name for. That is eighty percent of the benefit, and it takes ninety seconds.",
          "Variable refresh rate is the one genuinely transformative feature of the last few years, and it is off by default on a surprising number of sets. Check the panel menu, not the console menu.",
          "HDR calibration is worth ten minutes with the built-in tool. Everything past that is diminishing returns unless you are chasing a specific colour target.",
        ],
      },
    ];

    for (const data of seed) {
      try {
        const existing = app.findRecordsByFilter("articles", `slug = "${data.slug}"`, "", 1, 0);
        if (existing && existing.length > 0) continue;
      } catch (_) {}

      const rec = new Record(articles);
      rec.set("title", data.title);
      rec.set("slug", data.slug);
      rec.set("dek", data.dek);
      rec.set("body", data.body);
      rec.set("image", data.image);
      rec.set("author", data.author);
      rec.set("date", data.date);
      rec.set("readTime", data.readTime);
      rec.set("tags", data.tags);
      rec.set("platforms", data.platforms);
      rec.set("status", "published");
      app.save(rec);
    }
  },
  (app) => {
    try {
      const admin = app.findAuthRecordByEmail("users", "admin@easygamernews.com");
      app.delete(admin);
    } catch (_) {}
  },
);
